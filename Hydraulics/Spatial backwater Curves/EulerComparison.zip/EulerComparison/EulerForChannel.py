import math
import arcpy
from arcpy import env
import os, sys, math
import numpy

#setup environment
env.workspace = r'C:\temp1\crosssction' #Need to change path
outpath = env.workspace

#input FC
inFC = outpath + "\\" + "repoint.shp"
field = "GRID_CODE"

Q = 30
n = 0.025
s = 0.001
y0 = 1.04
cellsize=0.1
x = [0, 0.005, 0.01, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 2, 4, 6, 8, 10, 20, 40, 60]
min = 100
WaterSur=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
channelbot = 0


for num in range(0,19):
    WaterSur[num] = min+(x[num]-x[0])*s + y0
    rows = arcpy.da.SearchCursor(inFC, field)
    A1 = 0
    b = 0
    P1 = 0
    R1 = 0
    temp = 0
    temp = WaterSur[num]
    for row in rows:
        val = float(row[0])
        if val < WaterSur[num]:
            A1 = A1 + (WaterSur[num] - val)*cellsize
            b = b + cellsize
            P1 = P1 + pow(pow(temp - val,2) + pow(0.1,2),0.5)
            R1 = A1/P1
            temp = val
    del rows
    del row
    #print ("%-15f %-15f %-15f %-15f %-15f %-15f " %(WaterSur[num], x[num] ,y0, A1, b, P1))
    V=Q/A1
    Se= (n**2)*(V**2)/(R1**1.333)
    F2= (V**2)*b/9.81/A1
    fy1= (s-Se)/(1-F2)
    y2p= y0+(fy1*(-x[num+1]+x[num]))

    #print ("%-15f %-15f %-15f %-15f %-15f %-15f " %(V, Se, F2, s, fy1, y2p))

    WaterSur[num] = min+(x[num]-x[0])*s + y2p
    rows = arcpy.da.SearchCursor(inFC, field)
    A2 = 0
    b = 0
    P2 = 0
    R2 = 0
    temp = 0
    temp = WaterSur[num]
    for row in rows:
        val = float(row[0])
        if val < WaterSur[num]:
            A2 = A2 + (WaterSur[num] - val)*cellsize
            b = b + cellsize
            P2 = P2 + pow(pow(temp - val,2) + pow(0.1,2),0.5)
            R2 = A2/P2
            temp = val
    del rows
    del row

    V= Q/A2
    Se=(n**2)*(V**2)/(R2**1.333)
    F2= (V**2)*b/9.81/A2
    fy2= (s-Se)/(1-F2)
    y0= y0+((fy1+fy2)/2*(-x[num+1]+x[num]))
    print ("%-15f %-15f" %(x[num+1], y0))
